import { motion } from 'framer-motion';
import { BookOpen, Loader2 } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';

interface StoryCardProps {
  storyHistory: string[];
  currentStory: string;
  isLoading: boolean;
}

const StoryCard = ({ storyHistory, currentStory, isLoading }: StoryCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex h-full flex-col rounded-xl border border-border/50 bg-card/80 shadow-lg backdrop-blur-sm"
    >
      <div className="flex items-center gap-2 border-b border-border/30 p-4">
        <BookOpen className="h-5 w-5 text-primary" />
        <h3 className="font-display text-lg font-semibold text-foreground">冒險紀事</h3>
      </div>

      <ScrollArea className="flex-1 p-5">
        {/* Previous stories - faded */}
        {storyHistory.slice(0, -1).map((story, index) => (
          <div
            key={index}
            className="mb-4 border-b border-border/20 pb-4 text-sm leading-relaxed text-muted-foreground/60"
          >
            {story.split('\n').map((paragraph, pIndex) => (
              <p key={pIndex} className="mb-2">
                {paragraph}
              </p>
            ))}
          </div>
        ))}

        {/* Current story */}
        {currentStory && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-base leading-relaxed text-foreground"
          >
            {currentStory.split('\n').map((paragraph, index) => (
              <p key={index} className="mb-3">
                {paragraph}
              </p>
            ))}
          </motion.div>
        )}

        {/* Loading state */}
        {isLoading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex items-center justify-center gap-2 py-8 text-muted-foreground"
          >
            <Loader2 className="h-5 w-5 animate-spin" />
            <span>故事正在展開...</span>
          </motion.div>
        )}

        {/* Empty state */}
        {!currentStory && !isLoading && storyHistory.length === 0 && (
          <div className="py-8 text-center text-muted-foreground">
            <p>選擇一個行動開始你的冒險...</p>
          </div>
        )}
      </ScrollArea>
    </motion.div>
  );
};

export default StoryCard;
