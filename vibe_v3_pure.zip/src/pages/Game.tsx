import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { AlertTriangle, Settings, Loader2, Menu, Trash2, Shield, Heart, Gem, Swords, Clock, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetFooter,
} from '@/components/ui/sheet';
import { useToast } from '@/hooks/use-toast';
import { PlayerData, ActionOption, AIResponse, InventoryItem } from '@/types/game';
import {
  loadPlayer,
  savePlayer,
  loadApiKey,
  loadThrottleSetting,
  updatePlayerStats,
  addToInventory,
  removeFromInventory,
  addToStoryHistory,
  addToActionLog,
  deletePlayer,
  checkForLevelUp,
} from '@/lib/localStorage';
import { getLocationById } from '@/data/locations';
import { getItemById, Item } from '@/data/items';
import { getEnemyById, Enemy } from '@/data/enemies';
import {
  buildGamePrompt,
  buildArrivalPrompt,
  buildActionPrompt,
  buildFightResultPrompt,
} from '@/lib/promptTemplate';
import { callGroqAPI, parseAIResponse } from '@/lib/groqApi';
import CharacterCreation from '@/components/game/CharacterCreation';
import PlayerStatusCard from '@/components/game/PlayerStatusCard';
import InventoryCard from '@/components/game/InventoryCard';
import ActionButtons from '@/components/game/ActionButtons';
import LocationPanel from '@/components/game/LocationPanel';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const COOLDOWN_SECONDS = 15;

// --- Combat Action Type ---
type CombatAction = 'FIGHT' | 'FLEE' | { type: 'USE_ITEM'; itemId: string };

// --- Combat Panel Component ---
const CombatPanel = ({
  enemy,
  playerInventory,
  onCombatAction,
  isLoading,
  isOnCooldown,
  cooldownTimer
}: {
  enemy: Enemy,
  playerInventory: InventoryItem[],
  onCombatAction: (action: CombatAction) => void,
  isLoading: boolean,
  isOnCooldown: boolean,
  cooldownTimer: number
}) => {
  const combatItems = playerInventory.filter(item =>
    item.type === 'consumable' &&
    (item.effect?.type === 'DEAL_DAMAGE' || item.effect?.type === 'GUARANTEE_FLEE')
  );

  const isDisabled = isLoading || isOnCooldown;

  return (
    <Card className="border-destructive bg-destructive/10">
      <CardHeader>
        <CardTitle className="font-display text-xl text-destructive flex items-center gap-2">
          <Swords /> 遭遇敵人！
        </CardTitle>
        <p className="text-sm text-muted-foreground pt-1">{enemy.description}</p>
      </CardHeader>
      <CardContent>
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-bold">{enemy.name}</h3>
          <div className="flex gap-4 text-sm">
            <span className="flex items-center gap-1"><Heart className="h-4 w-4 text-red-500" /> {enemy.health}</span>
            <span className="flex items-center gap-1"><Shield className="h-4 w-4 text-blue-500" /> {enemy.defense}</span>
            <span className="flex items-center gap-1"><Gem className="h-4 w-4 text-yellow-500" /> {enemy.gold.join('-')}</span>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-2">
          <Button onClick={() => onCombatAction('FIGHT')} disabled={isDisabled} className="w-full">
            {isLoading ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : isOnCooldown ? (
              <Clock className="mr-2 h-4 w-4" />
            ) : (
              <Swords className="mr-2 h-4 w-4" />
            )}
            {isOnCooldown ? `冷卻中 (${cooldownTimer}s)` : '迎戰'}
          </Button>

          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" disabled={isDisabled || combatItems.length === 0} className="w-full">
                <Package className="mr-2 h-4 w-4" /> 物品
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-60">
               <div className="grid gap-4">
                <div className="space-y-2">
                  <h4 className="font-medium leading-none">戰鬥物品</h4>
                  <p className="text-sm text-muted-foreground">選擇要使用的物品。</p>
                </div>
                <div className="grid gap-2">
                  {combatItems.map((item) => (
                     <Button
                        key={item.id}
                        variant="outline"
                        onClick={() => onCombatAction({ type: 'USE_ITEM', itemId: item.id })}
                      >
                        {item.name} (x{item.quantity})
                      </Button>
                  ))}
                </div>
              </div>
            </PopoverContent>
          </Popover>

          <Button variant="outline" onClick={() => onCombatAction('FLEE')} disabled={isDisabled} className="w-full">
            逃跑
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

const Game = () => {
  const navigate = useNavigate();
  const { toast } = useToast();

  const [player, setPlayer] = useState<PlayerData | null>(null);
  const [currentStory, setCurrentStory] = useState('');
  const [actions, setActions] = useState<ActionOption[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [hasApiKey, setHasApiKey] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);
  const [currentEnemy, setCurrentEnemy] = useState<Enemy | null>(null);
  const [currentCombatEnemy, setCurrentCombatEnemy] = useState<Enemy | null>(null);

  const [isThrottlingEnabled, setIsThrottlingEnabled] = useState(false);
  const [isOnCooldown, setIsOnCooldown] = useState(false);
  const [cooldownTimer, setCooldownTimer] = useState(COOLDOWN_SECONDS);

  useEffect(() => {
    const savedPlayer = loadPlayer();
    const apiKey = loadApiKey();
    const throttleSetting = loadThrottleSetting();
    setPlayer(savedPlayer);
    setHasApiKey(!!apiKey);
    setIsThrottlingEnabled(throttleSetting);
    setIsInitialized(true);

    if (savedPlayer && savedPlayer.storyHistory.length > 0) {
      setCurrentStory(savedPlayer.storyHistory[savedPlayer.storyHistory.length - 1]);
      setActions([
        { description: '繼續探索此地', actionCode: 'EXPLORE' },
        { description: '休息恢復體力', actionCode: 'REST' },
        { description: '查看四周環境', actionCode: 'TALK' },
      ]);
    }
  }, []);

  useEffect(() => {
    if (!isOnCooldown) return;
    const interval = setInterval(() => {
      setCooldownTimer(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          setIsOnCooldown(false);
          return COOLDOWN_SECONDS;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [isOnCooldown]);

  const triggerCooldown = () => {
    if (isThrottlingEnabled) {
      setIsOnCooldown(true);
      setCooldownTimer(COOLDOWN_SECONDS);
    }
  };

  const callAI = useCallback(
    async (context: string, playerData: PlayerData, forceUpdate: boolean = false) => {
      const apiKey = loadApiKey();
      if (!apiKey) {
        toast({ title: '缺少 API Key', variant: 'destructive' });
        return;
      }
      triggerCooldown();
      setIsLoading(true);
      try {
        const prompt = buildGamePrompt(playerData, context);
        const rawResponse = await callGroqAPI(apiKey, prompt);
        const parsedResponse = parseAIResponse(rawResponse);
        processAIResponse(parsedResponse, playerData, forceUpdate);
      } catch (error) {
        toast({ title: 'AI 錯誤', description: '連線失敗', variant: 'destructive' });
      } finally {
        setIsLoading(false);
      }
    },
    [toast, isThrottlingEnabled]
  );

  const processAIResponse = useCallback(
    (response: AIResponse, playerData: PlayerData, forceUpdate: boolean = false) => {
      let updatedPlayer = { ...playerData };

      if (response.enemyIdToFight && !forceUpdate) {
        const enemy = getEnemyById(response.enemyIdToFight);
        if (enemy) {
          setCurrentEnemy(enemy);
          setCurrentCombatEnemy({ ...enemy });
          setCurrentStory(response.story);
          setActions(response.actions);
          savePlayer(updatedPlayer);
          setPlayer(updatedPlayer);
          return;
        }
      }

      setCurrentEnemy(null);
      setCurrentCombatEnemy(null);
      updatedPlayer = updatePlayerStats(updatedPlayer, response.statusChanges);

      response.statusChanges.itemChanges.forEach((itemChange) => {
        const itemData = getItemById(itemChange.name);
        if (itemData) {
          if (itemChange.action === 'add') {
            updatedPlayer = addToInventory(updatedPlayer, itemData, itemChange.quantity);
            toast({ title: '獲得物品', description: `你獲得了 ${itemData.name}` });
          } else {
             updatedPlayer = removeFromInventory(updatedPlayer, itemData.id, itemChange.quantity);
          }
        }
      });

      updatedPlayer = addToStoryHistory(updatedPlayer, response.story);
      if (updatedPlayer.storyHistory.length > 5) {
        updatedPlayer.storyHistory.splice(0, updatedPlayer.storyHistory.length - 5);
      }

      const { player: leveledUpPlayer, didLevelUp } = checkForLevelUp(updatedPlayer);
      updatedPlayer = leveledUpPlayer;

      if (didLevelUp) toast({ title: '等級提升！' });

      if (response.statusChanges.special.includes('死亡') || updatedPlayer.health <= 0) {
        updatedPlayer.health = 0;
      }

      savePlayer(updatedPlayer);
      setPlayer(updatedPlayer);
      setCurrentStory(response.story);
      setActions(response.actions);
    },
    [toast]
  );

  const handleAction = useCallback(
    (action: ActionOption) => {
      if (!player || isOnCooldown) return;
      const updatedPlayer = addToActionLog(player, action.description);
      setPlayer(updatedPlayer);
      savePlayer(updatedPlayer);
      callAI(buildActionPrompt(action.description), updatedPlayer);
    },
    [player, callAI, isOnCooldown]
  );

  // --- 合併後的戰鬥邏輯 ---
  const handleCombatAction = useCallback((action: CombatAction) => {
    if (!player || !currentCombatEnemy || !currentEnemy || isOnCooldown) return;

    let updatedPlayer = { ...player };
    let updatedEnemy = { ...currentCombatEnemy }; 
    let combatLog = "";

    // 1. 處理玩家動作
    if (typeof action === 'object' && action.type === 'USE_ITEM') {
      const item = getItemById(action.itemId);
      if (!item) return;
      updatedPlayer = removeFromInventory(updatedPlayer, item.id, 1);

      if (item.effect?.type === 'GUARANTEE_FLEE') {
        toast({ title: '使用煙霧彈！', description: '成功逃離戰場。' });
        setCurrentEnemy(null);
        setCurrentCombatEnemy(null);
        setActions([{ description: '繼續探索', actionCode: 'EXPLORE' }]);
        savePlayer(updatedPlayer);
        setPlayer(updatedPlayer);
        return;
      }
      
      if (item.effect?.type === 'DEAL_DAMAGE') {
        const damage = item.effect.amount;
        updatedEnemy.health -= damage;
        toast({ title: `你使用了 ${item.name}`, description: `對 ${updatedEnemy.name} 造成 ${damage} 點傷害！` });
        combatLog += `在戰鬥中，我使用了 ${item.name}，對 ${updatedEnemy.name} 造成了 ${damage} 點傷害。`;
      }
    }
    else if (action === 'FLEE') {
      if (Math.random() < 0.5) {
        toast({ title: '逃跑成功', description: '你成功甩開了敵人！' });
        setCurrentEnemy(null);
        setCurrentCombatEnemy(null);
        setActions([{ description: '繼續探索', actionCode: 'EXPLORE' }]);
        return;
      } else {
        toast({ title: '逃跑失敗', description: '你未能逃脫，敵人發動追擊！', variant: 'destructive' });
        combatLog = '我試圖逃跑但失敗了。';
      }
    }
    else if (action === 'FIGHT') {
      const pDmg = Math.max(1, updatedPlayer.attack - updatedEnemy.defense);
      updatedEnemy.health -= pDmg;
      toast({ title: '攻擊！', description: `造成 ${pDmg} 點傷害。` });
      combatLog = `我攻擊了 ${updatedEnemy.name}，造成了 ${pDmg} 點傷害。`;
    }

    // 2. 檢查敵人死亡
    if (updatedEnemy.health <= 0) {
      const exp = currentEnemy.exp;
      const gold = Math.floor(Math.random() * (currentEnemy.gold[1] - currentEnemy.gold[0] + 1)) + currentEnemy.gold[0];
      let loot: { itemName: string; quantity: number }[] = [];
      currentEnemy.loot.forEach(l => {
        if (Math.random() < l.chance) {
          const item = getItemById(l.itemId);
          if (item) { loot.push({ itemName: item.name, quantity: 1 }); updatedPlayer = addToInventory(updatedPlayer, item, 1); }
        }
      });
      updatedPlayer = updatePlayerStats(updatedPlayer, { healthChange: 0, expChange: exp, goldChange: gold });
      toast({ title: '戰鬥勝利！', description: `獲得 ${exp} 經驗與 ${gold} 金幣！` });

      const { player: leveledUpPlayer, didLevelUp } = checkForLevelUp(updatedPlayer);
      if (didLevelUp) toast({ title: '等級提升！' });
      
      const resCtx = buildFightResultPrompt(player.name, currentEnemy.name, { outcome: 'win', playerDamageTaken: 0, enemyDamageTaken: currentEnemy.health, expGained: exp, goldGained: gold, lootGained: loot });
      callAI(combatLog + " " + resCtx, leveledUpPlayer, true);
      savePlayer(leveledUpPlayer);
      setPlayer(leveledUpPlayer);
      setCurrentEnemy(null);
      setCurrentCombatEnemy(null);
      return;
    }

    // 3. 敵人反擊
    const eDmg = Math.max(1, updatedEnemy.attack - updatedPlayer.defense);
    updatedPlayer.health -= eDmg;
    toast({ description: `${updatedEnemy.name} 反擊，造成 ${eDmg} 點傷害！`, variant: 'destructive' });
    combatLog += ` ${updatedEnemy.name} 反擊，使我損失了 ${eDmg} 點生命。`;

    // 4. 檢查玩家死亡
    if (updatedPlayer.health <= 0) {
      updatedPlayer.health = 0;
      toast({ title: '戰鬥失敗', variant: 'destructive' });
      const resCtx = buildFightResultPrompt(player.name, currentEnemy.name, { outcome: 'lose', playerDamageTaken: player.health, enemyDamageTaken: currentEnemy.health - updatedEnemy.health, expGained: 0, goldGained: 0, lootGained: null });
      callAI(combatLog + " " + resCtx, updatedPlayer, true);
      savePlayer(updatedPlayer);
      setPlayer(updatedPlayer);
      setCurrentEnemy(null);
      setCurrentCombatEnemy(null);
      return;
    }

    // 5. 繼續回合
    setPlayer(updatedPlayer);
    setCurrentCombatEnemy(updatedEnemy);
    savePlayer(updatedPlayer);
  }, [player, currentCombatEnemy, currentEnemy, callAI, isOnCooldown, toast]);

  const handleLocationChange = useCallback((locationId: string) => {
      if (!player || player.currentLocation === locationId || isOnCooldown) return;
      setCurrentEnemy(null);
      setCurrentCombatEnemy(null);
      const location = getLocationById(locationId);
      if (!location) return;
      const updatedPlayer = { ...player, currentLocation: locationId };
      const loggedPlayer = addToActionLog(updatedPlayer, `前往${location.name}`);
      setPlayer(loggedPlayer);
      savePlayer(loggedPlayer);
      callAI(buildArrivalPrompt(location.name), loggedPlayer);
    },
    [player, callAI, isOnCooldown]
  );

  const handleCreateCharacter = useCallback((newPlayer: PlayerData) => {
      savePlayer(newPlayer);
      setPlayer(newPlayer);
      callAI(buildArrivalPrompt(getLocationById(newPlayer.currentLocation)?.name || '小村莊'), newPlayer);
    },
    [callAI]
  );

  const handleResetGame = () => {
    if (window.confirm('重置遊戲？')) {
      deletePlayer();
      setTimeout(() => window.location.reload(), 500);
    }
  };

  const applyItemEffect = useCallback((playerData: PlayerData, item: Item): PlayerData => {
    let upP = { ...playerData };
    if (!item.effect) return upP;
    if (item.effect.type === 'HEAL') {
      upP.health = Math.min(upP.maxHealth, upP.health + item.effect.amount);
    } else if (item.effect.type === 'PERMANENT_STAT') {
      const stat = item.effect.stat;
      upP[stat] += item.effect.amount;
      if(stat === 'maxHealth') upP.health += item.effect.amount;
    }
    return upP;
  }, []);

  const handleUseItem = useCallback((itemId: string) => {
    if (!player) return;
    const item = player.inventory.find(i => i.id === itemId);
    if (!item || item.type !== 'consumable') return;
    let upP = applyItemEffect(player, item);
    upP = removeFromInventory(upP, itemId, 1);
    setPlayer(upP);
    savePlayer(upP);
  }, [player, applyItemEffect]);

  const handleEquipItem = useCallback((itemId: string) => {
    if (!player) return;
    const newItem = getItemById(itemId);
    if (!newItem || (newItem.type !== 'weapon' && newItem.type !== 'armor')) return;
    let upP = { ...player };
    if (newItem.type === 'weapon') {
      const old = getItemById(player.equippedWeapon || '');
      if (old) upP.attack -= (old.stats?.attack || 0);
      upP.equippedWeapon = itemId;
      upP.attack += (newItem.stats?.attack || 0);
    } else {
      const old = getItemById(player.equippedArmor || '');
      if (old) upP.defense -= (old.stats?.defense || 0);
      upP.equippedArmor = itemId;
      upP.defense += (newItem.stats?.defense || 0);
    }
    setPlayer(upP);
    savePlayer(upP);
  }, [player]);

  if (!isInitialized) return <div className="flex h-screen items-center justify-center">載入中...</div>;
  if (!player) return <CharacterCreation onCreateCharacter={handleCreateCharacter} />;
  if (!hasApiKey) return <div className="flex h-screen items-center justify-center"><Button onClick={() => navigate('/settings')}>請先設定 API Key</Button></div>;

  return (
    <div className="relative min-h-screen bg-gradient-to-br from-background via-background to-secondary/20">
      <Sheet>
        <SheetTrigger asChild><Button variant="ghost" size="icon" className="absolute top-4 right-4 z-50"><Menu /></Button></SheetTrigger>
        <SheetContent className="flex w-full flex-col p-0 sm:max-w-lg">
          <SheetHeader className="p-6"><SheetTitle className="font-display text-2xl">冒險者選單</SheetTitle></SheetHeader>
          <div className="flex-1 overflow-y-auto p-6 pt-0 space-y-4">
            <PlayerStatusCard player={player} />
            <InventoryCard inventory={player.inventory} equippedWeapon={player.equippedWeapon} equippedArmor={player.equippedArmor} onUseItem={handleUseItem} onEquipItem={handleEquipItem} />
            <LocationPanel currentLocationId={player.currentLocation} onLocationChange={handleLocationChange} isLoading={isLoading || isOnCooldown} />
          </div>
          <SheetFooter className="p-6 border-t"><Button variant="outline" className="w-full" onClick={() => navigate('/settings')}>設定</Button><Button variant="destructive" className="w-full mt-2" onClick={handleResetGame}>重置</Button></SheetFooter>
        </SheetContent>
      </Sheet>

      <main className="container mx-auto flex h-screen max-w-3xl flex-col gap-4 p-4 pt-20">
        <div className="flex-1 flex flex-col gap-4 overflow-y-auto">
          {player.storyHistory.length > 1 && (
            <Accordion type="single" collapsible><AccordionItem value="history"><AccordionTrigger>歷史回顧</AccordionTrigger><AccordionContent className="space-y-4 pt-4">{player.storyHistory.slice(0, -1).reverse().map((s, i) => <p key={i} className="text-muted-foreground">{s}</p>)}</AccordionContent></AccordionItem></Accordion>
          )}
          <Card className="flex-1">
            <CardHeader><CardTitle className="font-display text-xl">當前情節</CardTitle></CardHeader>
            <CardContent className="text-foreground/90">{isLoading && !currentStory ? <Loader2 className="animate-spin" /> : currentStory || '冒險即將開始...'}</CardContent>
          </Card>
        </div>
        {currentCombatEnemy ? (
          <CombatPanel enemy={currentCombatEnemy} playerInventory={player.inventory} onCombatAction={handleCombatAction} isLoading={isLoading} isOnCooldown={isOnCooldown} cooldownTimer={cooldownTimer} />
        ) : (
          <ActionButtons actions={actions} onAction={handleAction} isLoading={isLoading} isOnCooldown={isOnCooldown} cooldownTimer={cooldownTimer} />
        )}
      </main>
    </div>
  );
};

export default Game;